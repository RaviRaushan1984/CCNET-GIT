﻿namespace CruiseControl.Common.Messages
{
    /// <summary>
    /// A blank message.
    /// </summary>
    public class Blank
    {
    }
}
