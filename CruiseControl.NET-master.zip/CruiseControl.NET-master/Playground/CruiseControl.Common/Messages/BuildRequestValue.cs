﻿namespace CruiseControl.Common.Messages
{
    /// <summary>
    /// The value for a request.
    /// </summary>
    public class BuildRequestValue
    {
    }
}