﻿namespace CruiseControl.Command
{
    public class Command
    {
        #region Public properties
        #region Name
        public string Name { get; set; }
        #endregion

        #region Arguments
        public string[] Arguments { get; set; }
        #endregion
        #endregion
    }
}
