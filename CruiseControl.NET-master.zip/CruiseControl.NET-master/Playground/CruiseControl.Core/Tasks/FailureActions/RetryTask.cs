﻿namespace CruiseControl.Core.Tasks.FailureActions
{
    public class RetryTask
        : TaskFailureAction
    {
    }
}
