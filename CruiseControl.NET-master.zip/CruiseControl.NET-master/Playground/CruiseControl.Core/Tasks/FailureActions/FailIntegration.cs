﻿namespace CruiseControl.Core.Tasks.FailureActions
{
    public class FailIntegration
        : TaskFailureAction
    {
    }
}
